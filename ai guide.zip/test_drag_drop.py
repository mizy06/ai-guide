import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from PySide6.QtWidgets import QApplication
from app import Application

def test_drag_drop():
    print("Testing drag and drop functionality...")
    
    app = QApplication.instance()
    if app is None:
        app = QApplication(sys.argv)
    
    application = Application()
    
    try:
        gui_app = application.initialize()
        print("✓ Application initialized")
        
        main_window = application.main_window
        center_panel = main_window.get_center_panel()
        
        print(f"✓ Drop zone found: {center_panel.drop_zone}")
        print(f"✓ File dropped signal connected: {center_panel.drop_zone.fileDropped}")
        
        test_file = r"C:\Users\L\Downloads\test.txt"
        if not Path(test_file).exists():
            print(f"\nCreating test file: {test_file}")
            Path(test_file).parent.mkdir(parents=True, exist_ok=True)
            with open(test_file, 'w', encoding='utf-8') as f:
                f.write("This is a test file for AI file intelligence system.")
        
        print(f"\nSimulating file drop: {test_file}")
        center_panel.drop_zone.fileDropped.emit(test_file)
        
        print("✓ File drop signal emitted")
        
        from PySide6.QtCore import QTimer
        timer = QTimer()
        timer.timeout.connect(app.quit)
        timer.start(5000)
        
        print("✓ Application will close in 5 seconds...")
        print("✓ Check console for debug output")
        
        exit_code = app.exec()
        print(f"\n✓ Application exited with code: {exit_code}")
        
    except Exception as e:
        print(f"\n✗ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(test_drag_drop())
