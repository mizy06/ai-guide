import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from app.llm import LLMRouter, TaskType


async def test_llm_router():
    print("Testing LLM Router...")
    
    router = LLMRouter()
    
    print(f"Available providers: {router.get_available_providers()}")
    print(f"Task routing: {router.get_task_routing()}")
    
    from app.llm.base_provider import LLMRequest
    
    request = LLMRequest(
        messages=[{"role": "user", "content": "Hello! Can you help me organize files?"}],
        task_type=TaskType.CHAT,
        temperature=0.7,
        max_tokens=100,
        stream=False
    )
    
    try:
        print("\nSending test request to DeepSeek...")
        response = await router.route(request)
        print(f"Response: {response.content[:100]}...")
        print(f"Model: {response.model}")
        print(f"Latency: {response.latency:.2f}s")
        print(f"Tokens: {response.usage['total_tokens']}")
        print(f"Cost: ${response.usage['cost']:.6f}")
        
        print(f"\nStats: {router.get_stats()}")
        print("\nTest passed!")
        
    except Exception as e:
        print(f"Test failed: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(test_llm_router())
