import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from app.agent import FileIntelligenceAgent
from app.llm import LLMRouter
from app.memory import MemorySystem
from app.tools import ToolRegistry
from app.core import SafetyConfig


async def test_file_processing():
    print("Testing file processing...")
    
    try:
        router = LLMRouter()
        print(f"✓ LLM Router initialized")
        print(f"  Available providers: {router.get_available_providers()}")
        
        memory = MemorySystem()
        print(f"✓ Memory system initialized")
        
        tools = ToolRegistry(SafetyConfig())
        print(f"✓ Tool registry initialized")
        
        agent = FileIntelligenceAgent(router, memory, tools)
        print(f"✓ Agent initialized")
        
        test_file = r"C:\Users\L\Downloads\test.txt"
        if not Path(test_file).exists():
            print(f"\nCreating test file: {test_file}")
            Path(test_file).parent.mkdir(parents=True, exist_ok=True)
            with open(test_file, 'w', encoding='utf-8') as f:
                f.write("This is a test file for AI file intelligence system.")
        
        print(f"\nProcessing file: {test_file}")
        
        async for result in agent.process_file(test_file):
            print(f"  [{result['type']}] ", end='')
            if result['type'] == 'status':
                print(result['message'])
            elif result['type'] == 'plan':
                print(f"Intent: {result['intent']}, Task: {result['task_type']}, Confidence: {result['confidence']:.2f}")
            elif result['type'] == 'tool_result':
                print(f"Tool: {result['tool']}")
            elif result['type'] == 'llm_response':
                print(f"LLM: {result['task_type']}, Latency: {result['latency']:.2f}s")
            elif result['type'] == 'confirmation_required':
                print(f"Confirmation needed: {result['message']}")
            elif result['type'] == 'complete':
                print(f"Complete")
            elif result['type'] == 'error':
                print(f"ERROR: {result.get('message', 'Unknown error')}")
        
        print(f"\n✓ File processing completed")
        
    except Exception as e:
        print(f"\n✗ Test failed: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(test_file_processing())
